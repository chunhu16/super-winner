﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Ipsos.Tools;
using System.Net.Mail;
using System.DirectoryServices;
using System.Text;
using System.IO;
using System.Net;
using Ipsos.Tools.Sql;
using InnoScreenIdeas.Bll;
using System.Configuration;
using InnoScreenIdeas.Model;

namespace IQ_Product_Support_Interface
{
    public partial class Default : System.Web.UI.Page
    {
        #region Constantes statics

        public static readonly string DB_CONNECTION = ConfigurationManager.ConnectionStrings["DB.Connection"].ToString();

        private static readonly char[] job_format1 = new char[] { 'n', 'n', '-', 'n', 'n', 'n', 'n', 'n', 'n' };
        private static readonly char[] job_format2 = new char[] { 'n', 'n', '-', 'n', 'n', 'n', 'n', 'n', 'n', '-', 'n', 'n' };
        private static readonly string DefaultMail = "mailto:";
        // New line character for mail format
        private static readonly string NewLine = "%0D%0A";
        private static readonly string DNewLine = NewLine + NewLine;
        private static readonly string TNewLine = DNewLine + NewLine;
        private static readonly string QNewLine = TNewLine + NewLine;
        private static readonly string DefaultSubject = "No Subject registered";

        #endregion

        private IList<CountryVO> countries;

        /// <summary>
        /// On load methods of the page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                SQLHelper.SetConnectionString(DB_CONNECTION);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            if(!IsPostBack){
                Welcome();
                List_test_country_to_hidden();
                job_code_error.Visible = false;
                DataBindCountries();
                set_sizes();
                
            }
            Identity_modified();
        }

        private void set_sizes()
        {
            double size1 = 100;
            set_sect1_sizes(size1);
        }

        private void set_sect1_sizes(double d)
        {
            // table
            table_sect1.Style.Add("Width", "50%");
            // cells on the right
            Unit unit = Unit.Percentage(d);
            drop_down_list_sect1.Width = Unit.Percentage(d + 1);
            text_box_sect1_1.Width = unit;
            text_box_sect1_2.Width = unit;
            text_box_sect1_3.Width = unit;
        }


        private void DataBindCountries()
        {
            this.countries = Country.GetCountrys();//.OrderBy(c => c.Label).ToList();
            CountryVO empty = new CountryVO();
            empty.Label = "";
            this.countries.Add(empty);
            this.countries = this.countries.OrderBy(c => c.Label).ToList();

            // Bind all DropDownList with countries
            BindDownDropListCountry(drop_down_list_sect1);
            BindDownDropListCountry(drop_down_list_sect6_1);
            BindDownDropListCountry(drop_down_list_sect6_2);
            BindDownDropListCountry(drop_down_list_sect6_3);
            BindDownDropListCountry(drop_down_list_sect6_4);
            BindDownDropListCountry(drop_down_list_sect6_5);
            BindDownDropListCountry(drop_down_list_sect6_6);
            BindDownDropListCountry(drop_down_list_sect6_7);
            BindDownDropListCountry(drop_down_list_sect6_8);
            BindDownDropListCountry(drop_down_list_sect6_9);
        }

        private void BindDownDropListCountry(DropDownList ddl)
        {
            ddl.DataSource = this.countries;
            ddl.DataTextField = "Label";
            ddl.DataValueField = "Label";
            ddl.DataBind();
        }

        #region First load methods

        /// <summary>
        /// If Ipsos user, initialize the Identity
        /// </summary>
        private void Welcome()
        {
            string identity = User.Identity.Name;
            if (identity.StartsWith("IPSOSGROUP\\"))
            {
                string[] backbackslash = new string[] { "\\" };
                string[] dot = new string[] { "." };

                string[] parts = identity.Split(backbackslash, StringSplitOptions.None);
                string[] person = parts[1].Split(dot, StringSplitOptions.None);

                string fname = person[0].Substring(0, 1).ToUpper() + person[0].Substring(1, person[0].Length - 1);
                string lname = person[1].Substring(0, 1).ToUpper() + person[1].Substring(1, person[1].Length - 1);

                text_box_sect1_1.Text = fname;
                text_box_sect1_2.Text = lname;
                hello.InnerText = "Hello " + fname + " " + lname;

                string email = person[0] + "." + person[1] + "@ipsos.com";
                text_box_sect1_3.Text = email;
            }
        }

        /// <summary>
        /// Hide every country of the test country, exept the first
        /// </summary>
        private void List_test_country_to_hidden()
        {
            list6num2.Visible = false;
            list6num3.Visible = false;
            list6num4.Visible = false;
            list6num5.Visible = false;
            list6num6.Visible = false;
            list6num7.Visible = false;
            list6num8.Visible = false;
            list6num9.Visible = false;
        }

        #endregion

        /// <summary>
        /// Update the identity of the user depending of the infos fields
        /// </summary>
        protected void Identity_modified()
        {
            string fname = text_box_sect1_1.Text;
            string lname = text_box_sect1_2.Text;

            text_box_sect1_1.Text = fname;
            text_box_sect1_2.Text = lname;
            hello.InnerText = "Hello " + fname + " " + lname;

            string email = fname.ToLower() + "." + lname.ToLower() + "@ipsos.com";
            text_box_sect1_3.Text = email;
        }

        #region Test Country buttons methods

        /// <summary>
        /// Set the next test country at visible
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Add_test_country(object sender, EventArgs e)
        {
            int next = Int32.Parse(CurrFieldCountry.Text) + 1 ;
            bool done = false;
            if (next == 2)
            {
                list6num2.Visible = true;
                done = true;
            }
            else if (next == 3)
            {
                list6num3.Visible = true;
                done = true;
            }
            else if (next == 4)
            {
                list6num4.Visible = true;
                done = true;
            }
            else if (next == 5)
            {
                list6num5.Visible = true;
                done = true;
            }
            else if (next == 6)
            {
                list6num6.Visible = true;
                done = true;
            }
            else if (next == 7)
            {
                list6num7.Visible = true;
                done = true;
            }
            else if (next == 8)
            {
                list6num8.Visible = true;
                done = true;
            }
            else if (next == 9)
            {
                list6num9.Visible = true;
                done = true;
            }
            if (done)
            {
                CurrFieldCountry.Text = next.ToString();
            }
            text_box_sect8.Focus();
        }

        /// <summary>
        /// Set the current test country at invisible
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Remove_test_country(object sender, EventArgs e)
        {
            int curr = Int32.Parse(CurrFieldCountry.Text);
            if (curr == 2)
            {
                list6num2.Visible = false;
            }
            else if (curr == 3)
            {
                list6num3.Visible = false;
            }
            else if (curr == 4)
            {
                list6num4.Visible = false;
            }
            else if (curr == 5)
            {
                list6num5.Visible = false;
            }
            else if (curr == 6)
            {
                list6num6.Visible = false;
            }
            else if (curr == 7)
            {
                list6num7.Visible = false;
            }
            else if (curr == 8)
            {
                list6num8.Visible = false;
            }
            else if (curr == 9)
            {
                list6num9.Visible = false;
            }
            if (curr != 1)
            {
                curr--;
                CurrFieldCountry.Text = curr.ToString();
            }

            text_box_sect8.Focus();
        }

        #endregion

        #region summary & mail management

        /// <summary>
        /// Update the summary section and the mail content with all informations registered
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Add_to_sum(object sender, EventArgs e)
        {
            SendLink.Attributes["href"] = DefaultMail;
            //Add receiver(s)
            Add_to_sum_contact();
            Add_to_sum_subject();
            //Add header to the mail
            Add_mail_header();
            Add_to_sum_infos();
            bool jobCodeValid = Add_to_sum_job_code();
            Add_to_sum_description();
            Add_to_sum_product();
            Add_to_sum_test_country();
            Add_to_sum_method();
            Add_to_sum_problem();
            if (jobCodeValid)
            {
                SendLink.Focus();
            }
            else
            {
                text_area_sect4.Focus();
            }
        }

        /// <summary>
        /// Add the header to the summary and the mail
        /// </summary>
        private void Add_mail_header()
        {
            SendLink.Attributes["href"] += "Body=";
            string line0 = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam rutrum mattis odio ac dignissim. Etiam arcu eros, luctus vitae urna in, mollis malesuada velit. In hac habitasse platea dictumst.";
            string line1 = "Sed odio nunc, sollicitudin a tempor ac, eleifend ut turpis. Fusce quis aliquam elit. Aenean ac elementum nibh. Etiam interdum feugiat ex, sodales pharetra massa bibendum in.";
            string line2 = "In ac lorem bibendum, suscipit nisl eu, facilisis arcu. Aliquam a dolor ut erat consequat consectetur.";
            string line3 = "";
            SendLink.Attributes["href"] += line0 + NewLine + line1 + NewLine + line2 + NewLine + line3 + QNewLine;

            string[] lines = new string[4];
            lines[0] = line0;
            lines[1] = line1;
            lines[2] = line2;
            lines[3] = line3;

            Table table = new Table();
            foreach (string line in lines)
            {
                TableRow row = new TableRow();
                TableCell cell = new TableCell();
                cell.Text = line;

                row.Cells.Add(cell);
                table.Rows.Add(row);
            }
            table_summary_lheader.Controls.Add(table);
        }

        /// <summary>
        /// Update the summary and the mail content with the user's informations
        /// </summary>
        private void Add_to_sum_infos()
        {
            Table table = new Table();

            // fist name part
            TableRow FName = new TableRow();

            TableCell cell1_1 = new TableCell();
            cell1_1.CssClass = "table_summary_Info_c1";
            cell1_1.Text = "First Name";
            FName.Cells.Add(cell1_1);
            TableCell cell1_2 = new TableCell();
            cell1_2.Text = text_box_sect1_1.Text;
            FName.Cells.Add(cell1_2);

            table.Rows.Add(FName);

            //last name part
            TableRow LName = new TableRow();

            TableCell cell2_1 = new TableCell();
            cell2_1.CssClass = "table_summary_Info_c1";
            cell2_1.Text = "Last Name";
            LName.Cells.Add(cell2_1);
            TableCell cell2_2 = new TableCell();
            cell2_2.Text = text_box_sect1_2.Text;
            LName.Cells.Add(cell2_2);

            table.Rows.Add(LName);

            //mail part
            TableRow Email = new TableRow();

            TableCell cell3_1 = new TableCell();
            cell3_1.CssClass = "table_summary_Info_c1";
            cell3_1.Text = "Email";
            Email.Cells.Add(cell3_1);
            TableCell cell3_2 = new TableCell();
            cell3_2.Text = text_box_sect1_3.Text;
            Email.Cells.Add(cell3_2);

            table.Rows.Add(Email);

            SendLink.Attributes["href"] += "From: " ;
            SendLink.Attributes["href"] += text_box_sect1_1.Text + " " + text_box_sect1_2.Text + NewLine;
            SendLink.Attributes["href"] += text_box_sect1_3.Text;

            //country part
            if (!drop_down_list_sect1.SelectedValue.ToString().Equals(""))
            {
                TableRow Country = new TableRow();

                TableCell cell4_1 = new TableCell();
                cell4_1.CssClass = "table_summary_Info_c1";
                cell4_1.Text = "Country";
                Country.Cells.Add(cell4_1);
                TableCell cell4_2 = new TableCell();
                cell4_2.Text = drop_down_list_sect1.SelectedValue.ToString();
                Country.Cells.Add(cell4_2);

                table.Rows.Add(Country);

                SendLink.Attributes["href"] += " , " + drop_down_list_sect1.SelectedValue.ToString();
            }

            table_summary_lsender_c.InnerText = "";
            table_summary_lsender_c.Controls.Add(table);


            SendLink.Attributes["href"] += TNewLine;
        }

        /// <summary>
        /// Update the summary and the mail content with the job book code
        /// </summary>
        /// <returns>True if format is correct or if job book code not registered</returns>
        private bool Add_to_sum_job_code()
        {
            table_summary_ljobcode_c.InnerText = "";

            bool begin = false;
            bool done = text_box_sect2.Text.Length == 0;
            char[] chars = text_box_sect2.Text.ToCharArray();
            char[] reference = new char[20];
            int cut1 = 2;
            int cut2 = 0;

            #region add subject to the email

            if (!text_area_sect3.InnerText.Equals(""))
            {
                SendLink.Attributes["href"] += "                                                      Subject:  " + text_area_sect3.InnerText;
            }
            else
            {
                SendLink.Attributes["href"] += "                                                      Subject:  " + DefaultSubject;
            }
            SendLink.Attributes["href"] += TNewLine;

            #endregion

            //determine if the size of the registered job book code is valid
            if (chars.Length == job_format1.Length)
            {
                reference = job_format1;
                begin = true;
            }
            else if (chars.Length == job_format2.Length)
            {
                reference = job_format2;
                begin = true;
                cut2 = 9;
            }

            if (begin)
            {
                int progress = 0;
                //run through the job book code registered  and the format at the same time to check the validity
                foreach (char curr in chars)
                {
                    if (progress == cut1 && curr != '-')
                    {
                        break;
                    }
                    else if (progress == cut2 && cut2 != 0 && curr != '-')
                    {
                        break;
                    }
                    if (!Char.IsNumber(curr) && progress != cut1 && progress != cut2)
                    {
                        break;
                    }

                    progress++;
                    //runned if format is correct
                    if (chars.Length == progress)
                    {
                        table_summary_ljobcode_c.InnerText = text_box_sect2.Text;
                        text_box_sect2.ForeColor = System.Drawing.Color.Black;
                        job_code_error.Visible = false;

                        SendLink.Attributes["href"] += "Project Job Book Code:  " + text_box_sect2.Text;
                        SendLink.Attributes["href"] += TNewLine;

                        done = true;
                    }
                }
                if (!done)
                {
                    //job book contains letters
                    text_box_sect2.ForeColor = System.Drawing.Color.Red;
                    job_code_error.Visible = true;
                    SendLink.Attributes["href"] += "Project Job Book Code:  " + "Bad format of Job Book Code";
                    SendLink.Attributes["href"] += TNewLine;
                }
            }
            else
            {
                if (text_box_sect2.Text.Length == 0)
                {
                    //job book empty
                    SendLink.Attributes["href"] += "Project Job Book Code:  " + "Job Book Code not registered";
                    SendLink.Attributes["href"] += TNewLine;
                }
                else
                {
                    //job book has not good size
                    text_box_sect2.ForeColor = System.Drawing.Color.Red;
                    job_code_error.Visible = true;
                    SendLink.Attributes["href"] += "Project Job Book Code:  " + "Bad format of Job Book Code";
                    SendLink.Attributes["href"] += TNewLine;
                }
            }
            
            return done || text_box_sect2.Text.Length == 0;
        }

        /// <summary>
        /// Update the summary and the mail content with the subject
        /// </summary>
        private void Add_to_sum_subject()
        {
            if (!text_area_sect3.InnerText.Equals(""))
            {
                SendLink.Attributes["href"] += "Subject=" + text_area_sect3.InnerText;
            }
            else
            {
                SendLink.Attributes["href"] += "Subject=" + DefaultSubject;
            }
            SendLink.Attributes["href"] += "&";

            table_summary_lsubject_c.InnerText = text_area_sect3.InnerText;
        }

        /// <summary>
        /// Get lines from stirng using "\r\n" new line charater
        /// </summary>
        /// <param name="text"></param>
        /// <returns>A table with each lines of the string</returns>
        private Table Get_lines_from_string(string text)
        {
            if (!text.Equals(""))
            {
                Table table = new Table();
                string desc = text;
                int jj = 0;
                int i = desc.IndexOf('\r'.ToString());
                int j = desc.IndexOf('\n'.ToString());

                while (i != -1 && j != -1 && i == j - 1)
                {
                    TableRow row = new TableRow();
                    TableCell cell = new TableCell();
                    cell.Text = desc.Substring(jj, i - jj);
                    row.Cells.Add(cell);
                    table.Rows.Add(row);

                    jj = j + 1;
                    i = desc.IndexOf('\r'.ToString(), i + 1);
                    j = desc.IndexOf('\n'.ToString(), j + 1);
                }
                TableRow end = new TableRow();
                TableCell endcell = new TableCell();
                endcell.Text = desc.Substring(jj, desc.Length - jj);
                end.Cells.Add(endcell);
                table.Rows.Add(end);

                return table;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Update the summary and the mail content with the description
        /// </summary>
        private void Add_to_sum_description()
        {
            
            if (!text_area_sect4.InnerText.Equals(""))
            {
                Table table = Get_lines_from_string(text_area_sect4.InnerText);
                bool multiLine = true;
                if (table != null)
                {
                    multiLine = table.Rows.Count > 1;
                    table_summary_ldescription_c.Controls.Add(table);
                }
                string desc = text_area_sect4.InnerText;
                int i = desc.IndexOf('\r'.ToString());
                int j = desc.IndexOf('\n'.ToString());

                while (i != -1 && j != -1 && i == j - 1)
                {
                    desc = desc.Insert(j + 1, NewLine);
                    i = desc.IndexOf('\r'.ToString(), i+1);
                    j = desc.IndexOf('\n'.ToString(), j+1);
                }

                SendLink.Attributes["href"] += "Descrition:"+ NewLine + desc;
                SendLink.Attributes["href"] += TNewLine;

                if (!multiLine)
                {
                    table_summary_ldescription_c.InnerText = text_area_sect4.InnerText;
                }
            }
            else
            {
                SendLink.Attributes["href"] += "Description: " + NewLine + "No Description provided." + TNewLine;
            }
        }

        /// <summary>
        /// Update the summary and the mail content with the product
        /// </summary>
        private void Add_to_sum_product()
        {
            if (radio_button_list_sect5.SelectedValue.ToString().Equals(""))
            {
                SendLink.Attributes["href"] += "Product:  " + "No Product selected.";
            }
            else
            {
                SendLink.Attributes["href"] += "Product:  " + @radio_button_list_sect5.SelectedValue.ToString();
            }
            SendLink.Attributes["href"] += TNewLine;

            table_summary_lproduct_c.InnerText = radio_button_list_sect5.SelectedValue.ToString();
        }

        /// <summary>
        /// Update the summary and the mail content with the test country(ies)
        /// </summary>
        private void Add_to_sum_test_country()
        {
            SendLink.Attributes["href"] += "Test Field Country(ies):" + NewLine;
            bool ctrselected = false;

            Table table = new Table();
            if (drop_down_list_sect6_1.Visible && !drop_down_list_sect6_1.SelectedValue.ToString().Equals(""))
            {
                TableRow row = new TableRow();

                TableCell cell1 = new TableCell();
                cell1.CssClass = "table_summary_country_c1";
                cell1.Text = "1)";
                row.Cells.Add(cell1);

                TableCell cell2 = new TableCell();
                cell2.Text = drop_down_list_sect6_1.SelectedValue.ToString();
                row.Cells.Add(cell2);

                table.Rows.Add(row);

                SendLink.Attributes["href"] += drop_down_list_sect6_1.SelectedValue.ToString() + NewLine;
                ctrselected = true;
            }
            if (drop_down_list_sect6_2.Visible && !drop_down_list_sect6_2.SelectedValue.ToString().Equals(""))
            {
                TableRow row = new TableRow();

                TableCell cell1 = new TableCell();
                cell1.CssClass = "table_summary_country_c1";
                cell1.Text = "2)";
                row.Cells.Add(cell1);

                TableCell cell2 = new TableCell();
                cell2.Text = drop_down_list_sect6_2.SelectedValue.ToString();
                row.Cells.Add(cell2);

                table.Rows.Add(row);

                SendLink.Attributes["href"] += drop_down_list_sect6_2.SelectedValue.ToString() + NewLine;
                ctrselected = true;
            }
            if (drop_down_list_sect6_3.Visible && !drop_down_list_sect6_3.SelectedValue.ToString().Equals(""))
            {
                TableRow row = new TableRow();

                TableCell cell1 = new TableCell();
                cell1.CssClass = "table_summary_country_c1";
                cell1.Text = "3)";
                row.Cells.Add(cell1);

                TableCell cell2 = new TableCell();
                cell2.Text = drop_down_list_sect6_3.SelectedValue.ToString();
                row.Cells.Add(cell2);

                table.Rows.Add(row);

                SendLink.Attributes["href"] += drop_down_list_sect6_3.SelectedValue.ToString() + NewLine;
                ctrselected = true;
            }
            if (drop_down_list_sect6_4.Visible && !drop_down_list_sect6_4.SelectedValue.ToString().Equals(""))
            {
                TableRow row = new TableRow();

                TableCell cell1 = new TableCell();
                cell1.CssClass = "table_summary_country_c1";
                cell1.Text = "4)";
                row.Cells.Add(cell1);

                TableCell cell2 = new TableCell();
                cell2.Text = drop_down_list_sect6_4.SelectedValue.ToString();
                row.Cells.Add(cell2);

                table.Rows.Add(row);

                SendLink.Attributes["href"] += drop_down_list_sect6_4.SelectedValue.ToString() + NewLine;
                ctrselected = true;
            }
            if (drop_down_list_sect6_5.Visible && !drop_down_list_sect6_5.SelectedValue.ToString().Equals(""))
            {
                TableRow row = new TableRow();

                TableCell cell1 = new TableCell();
                cell1.CssClass = "table_summary_country_c1";
                cell1.Text = "5)";
                row.Cells.Add(cell1);

                TableCell cell2 = new TableCell();
                cell2.Text = drop_down_list_sect6_5.SelectedValue.ToString();
                row.Cells.Add(cell2);

                table.Rows.Add(row);

                SendLink.Attributes["href"] += drop_down_list_sect6_5.SelectedValue.ToString() + NewLine;
                ctrselected = true;
            }
            if (drop_down_list_sect6_6.Visible && !drop_down_list_sect6_6.SelectedValue.ToString().Equals(""))
            {
                TableRow row = new TableRow();

                TableCell cell1 = new TableCell();
                cell1.CssClass = "table_summary_country_c1";
                cell1.Text = "6)";
                row.Cells.Add(cell1);

                TableCell cell2 = new TableCell();
                cell2.Text = drop_down_list_sect6_6.SelectedValue.ToString();
                row.Cells.Add(cell2);

                table.Rows.Add(row);

                SendLink.Attributes["href"] += drop_down_list_sect6_6.SelectedValue.ToString() + NewLine;
                ctrselected = true;
            }
            if (drop_down_list_sect6_7.Visible && !drop_down_list_sect6_7.SelectedValue.ToString().Equals(""))
            {
                TableRow row = new TableRow();

                TableCell cell1 = new TableCell();
                cell1.CssClass = "table_summary_country_c1";
                cell1.Text = "7)";
                row.Cells.Add(cell1);

                TableCell cell2 = new TableCell();
                cell2.Text = drop_down_list_sect6_7.SelectedValue.ToString();
                row.Cells.Add(cell2);

                table.Rows.Add(row);

                SendLink.Attributes["href"] += drop_down_list_sect6_7.SelectedValue.ToString() + NewLine;
                ctrselected = true;
            }
            if (drop_down_list_sect6_8.Visible && !drop_down_list_sect6_8.SelectedValue.ToString().Equals(""))
            {
                TableRow row = new TableRow();

                TableCell cell1 = new TableCell();
                cell1.CssClass = "table_summary_country_c1";
                cell1.Text = "8)";
                row.Cells.Add(cell1);

                TableCell cell2 = new TableCell();
                cell2.Text = drop_down_list_sect6_8.SelectedValue.ToString();
                row.Cells.Add(cell2);

                table.Rows.Add(row);

                SendLink.Attributes["href"] += drop_down_list_sect6_8.SelectedValue.ToString() + NewLine;
                ctrselected = true;
            }
            if (drop_down_list_sect6_9.Visible && !drop_down_list_sect6_9.SelectedValue.ToString().Equals(""))
            {
                TableRow row = new TableRow();

                TableCell cell1 = new TableCell();
                cell1.CssClass = "table_summary_country_c1";
                cell1.Text = "9)";
                row.Cells.Add(cell1);

                TableCell cell2 = new TableCell();
                cell2.Text = drop_down_list_sect6_9.SelectedValue.ToString();
                row.Cells.Add(cell2);

                table.Rows.Add(row);

                SendLink.Attributes["href"] += drop_down_list_sect6_9.SelectedValue.ToString() + NewLine;
                ctrselected = true;
            }
            table_summary_ltestcountry_c.Controls.Add(table);

            if (ctrselected)
            {
                SendLink.Attributes["href"] += DNewLine;
            }
            else
            {
                SendLink.Attributes["href"] += "No Country selected." + TNewLine;
            }
        }

        /// <summary>
        /// Update the summary and the mail content with the method used (on/off-line)
        /// </summary>
        private void Add_to_sum_method()
        {
            if (radio_button_list_sect7.SelectedValue.ToString().Equals(""))
            {
                SendLink.Attributes["href"] += "Method Used: " + NewLine + "No Method selected.";
            }
            else
            {
                SendLink.Attributes["href"] += "Method Used: " + NewLine + radio_button_list_sect7.SelectedValue.ToString();
            }
            SendLink.Attributes["href"] += TNewLine;

            table_summary_lmethod_c.InnerText = radio_button_list_sect7.SelectedValue.ToString();
        }

        /// <summary>
        /// Update the summary and the mail content with the kind oh problem encountered
        /// </summary>
        private void Add_to_sum_problem()
        {
            SendLink.Attributes["href"] += "Kind of Problem encountered:" + NewLine;
            bool empty = true;

            Table table = new Table();
            foreach (ListItem item in check_list_sect8.Items)
            {
                if (item.Selected)
                {
                    TableRow row = new TableRow();
                    if (item.ToString().Equals("Other"))
                    {
                        TableCell cell1 = new TableCell();
                        cell1.CssClass = "table_summary_pb_c1";
                        cell1.Text = item.ToString() + " : ";
                        row.Cells.Add(cell1);

                        TableCell cell2 = new TableCell();
                        cell2.Text = text_box_sect8.Text;
                        row.Cells.Add(cell2);

                        SendLink.Attributes["href"] += "Other: " + text_box_sect8.Text + NewLine;
                    }
                    else
                    {
                        TableCell cell = new TableCell();
                        cell.Text = item.ToString();
                        row.Cells.Add(cell);

                        SendLink.Attributes["href"] += item.ToString() + NewLine;
                    }
                    table.Rows.Add(row);

                    empty = false;
                }
            }
            table_summary_lproblem_c.InnerText = "";
            table_summary_lproblem_c.Controls.Add(table);
            
            if(empty)
            {
                SendLink.Attributes["href"] += "No Category selected." + NewLine;
            }
            SendLink.Attributes["href"] += DNewLine;
        }

        /// <summary>
        /// Update the summary and the mail content with the team to contact
        /// </summary>
        private void Add_to_sum_contact()
        {
            SendLink.Attributes["href"] += "hugo.chung@ipsos.com";
                //TODO
            SendLink.Attributes["href"] += "?";
        }

        /// <summary>
        /// Send the email using MailMessage class
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Send_Mail(Object sender, EventArgs e)
        {
            MailMessage mail = new MailMessage();
            mail.IsBodyHtml = true;
            StringBuilder stringBuilder = new StringBuilder();
            mail_content.RenderControl(new HtmlTextWriter(new StringWriter(stringBuilder)));
            mail.Body = stringBuilder.ToString();
            mail.Sender = new MailAddress(text_box_sect1_3.Text);
            mail.Subject = text_area_sect3.InnerText;
            if(UploadAttachment.HasFile){
                mail.Attachments.Add(new Attachment(UploadAttachment.PostedFile.InputStream, UploadAttachment.FileName));
            }
            SmtpClient client = new SmtpClient(@"smtp.gmail.com");
            client.Credentials = CredentialCache.DefaultNetworkCredentials;
            client.Send(mail);

        }
        #endregion 
    }
}